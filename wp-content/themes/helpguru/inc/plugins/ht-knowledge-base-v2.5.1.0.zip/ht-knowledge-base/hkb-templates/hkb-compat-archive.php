<?php
/*
*
* The compat template for displaying heroic knowledgebase CPT archive content
*
*/
?>

<!-- #ht-kb -->
<div id="hkb" class="hkb-template-archive">

    <?php hkb_get_template_part('hkb-searchbox', 'archive'); ?>

    <?php hkb_get_template_part('hkb-content', 'archive'); ?>

</div>
<!-- /#ht-kb -->