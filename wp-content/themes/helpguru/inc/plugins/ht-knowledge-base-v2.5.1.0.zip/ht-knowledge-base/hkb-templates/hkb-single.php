<?php
/*
*
* The template used for single page, for use by the theme
*
*/
?>
<?php get_header(); ?>

<?php hkb_get_template_part('hkb-compat', 'single'); ?>

<?php get_footer(); ?>